.model small
.stack 100h
.data
.code

main proc

mov dl, 'A'
mov ah, 2
int 21h

mov dl, 'r'
mov ah, 2
int 21h

mov dl, 'e'
mov ah, 2
int 21h

mov dl, 'e'
mov ah, 2
int 21h

mov dl, 'b'
mov ah, 2
int 21h

mov dl, 'a'
mov ah, 2
int 21h

mov dl, ' '
mov ah, 2
int 21h

mov dl, '6'
mov ah, 2
int 21h

mov dl, '8'
mov ah, 2
int 21h

mov dl, '7'
mov ah, 2
int 21h

mov dl, '7'
mov ah, 2
int 21h

mov dl, '0'
mov ah, 2
int 21h

mov ah, 4Ch
int 21h

main endp
end main




