.model small
.stack 100h
.data
.code

main proc

    mov dl,4
    mov al,5
    add dl,al      

    add dl,30h     
    mov ah,2      
    int 21h

    mov ah,4ch
    int 21h

main endp
end main



