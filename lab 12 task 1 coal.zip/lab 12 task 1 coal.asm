
.model small
.stack 100h
.data

.code
main proc

mov ax,@data
mov ds,ax

mov bx,1
mov cx,4

L1:
push cx
mov cx,bx
mov si,1

L2:
mov dx,si
add dl,48
mov ah,2
int 21h

inc si
loop L2

mov dl,10
mov ah,2
int 21h

mov dl,13
mov ah,2
int 21h

inc bx
pop cx
loop L1

mov ah,4ch
int 21h

main endp
end main

