.model small
.stack 100h
.code
main proc
           
    mov dl, 'H'
    mov ah,2h
    int 21h

    mov dl, 'E'
    mov ah,2h
    int 21h

    mov dl, 'L'
    mov ah,2h
    int 21h

    mov dl, 'L'
    mov ah,2h
    int 21h

    mov dl, 'O'
    mov ah,2h
    int 21h

main endp
end main



