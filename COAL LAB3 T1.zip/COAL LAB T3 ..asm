.model small
.stack 100h
.data
.code

main proc

    MOV AL, 2      
    ADD AL, 5      

    ADD AL, 30h    
    MOV DL, AL
    MOV AH, 2
    INT 21h        

    MOV AH, 4Ch
    INT 21h

main endp
end main



