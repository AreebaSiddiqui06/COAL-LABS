.model small
.stack 100h
.code
main proc

mov cx, 5

PrintA:
mov dl, 'A'
mov ah, 2
int 21h

dec cx
cmp cx, 0
jne PrintA

mov ah, 4ch
int 21h

main endp
end main




