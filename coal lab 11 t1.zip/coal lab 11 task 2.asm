

.model small
.stack 100h
.data
str db 'MADAM$',0
msg1 db 'Palindrome$'
msg2 db 'Not Palindrome$'
.code
main:
mov ax, @data
mov ds, ax

lea si, str
mov cx, 0

; Step 1: Push characters
push_loop:
mov al, [si]
cmp al, '$'
je start_check

push ax
inc si
inc cx
jmp push_loop

; Step 2: Compare
start_check:
lea si, str

check_loop:
cmp cx, 0
je palindrome

mov al, [si]
pop bx

cmp al, bl
jne not_palindrome

inc si
dec cx
jmp check_loop

palindrome:
lea dx, msg1
mov ah, 09h
int 21h
jmp exit

not_palindrome:
lea dx, msg2
mov ah, 09h
int 21h

exit:
mov ah, 4ch
int 21h
end main

ret