
.model small
.stack 100h
.data
str db 'HELLO$',0
msg db 'Count = $'
.code
main:
mov ax, @data
mov ds, ax

lea si, str
mov cx, 0

push_loop:
mov al, [si]
cmp al, '$'
je display

push ax
inc cx
inc si
jmp push_loop

display:
; Print message
lea dx, msg
mov ah, 09h
int 21h

; Convert CX to ASCII (only works for 1-digit numbers)
mov dl, cl
add dl, '0'

mov ah, 02h
int 21h

exit:
mov ah, 4ch
int 21h
end main

ret




