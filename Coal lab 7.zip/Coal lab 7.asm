
.model small
.stack 100h

.data
msg db 'Area = $'

.code
main proc

mov ax,@data
mov ds,ax

mov al,4
mov bl,5
mul bl

mov ah,0
mov bl,10
div bl

mov bh,ah
mov bl,al

mov dx,offset msg
mov ah,9
int 21h

mov dl,bl
add dl,48
mov ah,2
int 21h

mov dl,bh
add dl,48
mov ah,2
int 21h

mov ah,4ch
int 21h

main endp
end main



