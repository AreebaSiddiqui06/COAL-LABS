.model small
.stack 100h
.data
msg1 db 'enter number of elements: $'
msg2 db 13,10,'enter element: $'
msg3 db 13,10,13,10,'sum of elements = $'

arr db 10 dup(?)
n db ?
sum db 0

.code
main proc
mov ax,@data
mov ds,ax

lea dx,msg1
mov ah,09h
int 21h

mov ah,01h
int 21h
sub al,48
mov n,al

mov cl,n
mov ch,0
mov si,0

l1:
lea dx,msg2
mov ah,09h
int 21h

mov ah,01h
int 21h
sub al,48

mov arr[si],al
add sum,al

inc si
loop l1

lea dx,msg3
mov ah,09h
int 21h

mov al,sum
mov ah,0
mov bl,10
div bl

mov bh,ah      ; save remainder

add al,48
mov dl,al
mov ah,02h
int 21h

mov al,bh
add al,48
mov dl,al
mov ah,02h
int 21h

mov ah,4ch
int 21h

main endp
end main
